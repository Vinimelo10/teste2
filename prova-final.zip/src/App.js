import React from "react";
import Poems from "./components/Poems";

function App() {
  return (
    <div>
      <Poems />
    </div>
  );
}

export default App;
